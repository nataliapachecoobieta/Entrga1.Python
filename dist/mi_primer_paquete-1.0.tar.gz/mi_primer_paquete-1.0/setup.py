from setuptools import setup

setup (

    name= "mi_primer_paquete",
    version = "1.0",
    descripcion ="Paquete de destribucion",
    author = "Natalia Pacheco-Python",
    author_email ="nataliapachecoobieta@gmail.com",

    packages = ["mi_primer_paquete"]
)